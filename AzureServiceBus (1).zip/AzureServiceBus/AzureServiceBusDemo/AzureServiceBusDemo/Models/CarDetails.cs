﻿namespace AzureServiceBusDemo.Models
{
    public class CarDetails
    {
        public int CarId { get; set; }
        public string CarModel { get; set; }
        public string Price { get; set; }
        public string Status { get; set; }
    }
}
